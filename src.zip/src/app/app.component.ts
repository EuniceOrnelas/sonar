import { Component, OnInit } from '@angular/core';
import { AppServiceService } from './app-service.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'copilot-project';
  imageForm: FormGroup;
  completionForm: FormGroup;
  code; //autocompletó el código
  image='https://images.vexels.com/media/users/3/147930/isolated/preview/3d5937db16598fba327cf5e29ec2f8aa-icono-de-la-camara-del-telemetro.png';
  prompt='';
  constructor(private appService:AppServiceService, private fb:FormBuilder) //no autocompletó ni puso sugerencias para la instancia de appService
  { }

  ngOnInit(){
    this.imageForm=this.fb.group({
      prompt:['',Validators.compose([Validators.required,Validators.minLength(10)])], //no autocompletó pero para la segunda línea si
      size:['medium',Validators.compose([Validators.required])]
    });
    this.completionForm=this.fb.group({
      textPrompt:['',Validators.compose([Validators.required,Validators.minLength(10)])]
    });
  }

  generateImage(){
    console.log(this.imageForm.value);
    // const obj = {
    //   prompt: this.imageForm.value.prompt,
    //   size: this.imageForm.value.size
    // };
    // console.log(obj);
    this.appService.generateImage('https://d2e63rjlg57kwc.cloudfront.net/products/129622.png',this.imageForm.value.prompt,this.imageForm.value.size).subscribe((response:{success,data}) => {
      console.log('Response from API is:',response);
      this.image=response.data;
    }, (error) => {
      console.log('Error from API is', error);
    });
  }

  createCompletion(){
    console.log(this.completionForm.value);
    // const obj = {
    //   prompt: this.completionForm.value.prompt,
    //   size: this.completionForm.value.size
    // };
    // console.log(obj);
    this.appService.createCompletion(this.completionForm.value.textPrompt).subscribe((response:{success,data}) => {
      console.log('Response from API is:',response);
      this.code=response.data;
    }, (error) => {
      console.log('Error from API is', error);
    });
  }

}
