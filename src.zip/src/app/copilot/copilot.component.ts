import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copilot',
  templateUrl: './copilot.component.html',
  styleUrls: ['./copilot.component.scss']
})
export class CopilotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
