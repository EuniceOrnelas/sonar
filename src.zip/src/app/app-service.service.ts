import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppServiceService {
  user="admin";
  pass="password";
  authorizationData = 'Basic ' + btoa(this.user + ':' + this.pass);

  headerOptions = {
    'Accept': 'application/json',
    'Authorization': this.authorizationData
  };
  constructor(private http: HttpClient) //no autocompletó ni puso sugerencias para la instancia de http
  { }

  generateImage(image, prompt, size) {
    return this.http.post('/openai/generateImage', {image, prompt, size });
  }

  createCompletion(prompt) {
    return this.http.post('/openai/createCompletion', { prompt });
  }


}
